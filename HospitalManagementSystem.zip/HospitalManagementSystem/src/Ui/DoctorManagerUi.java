package Ui;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import entity.Doctor;
import repo.DoctorRepo;

public class DoctorManagerUi {
	
	public static void main(String[] args) 
	{
		DoctorRepo.loadDocs();
		JFrame f=new JFrame();
		f.setTitle("Doctor Manager Ui Md Humaid Husain 93");
		JLabel[] label=new JLabel[15];
		JPanel panel=new JPanel();
		int i;
		for( i=0;i<DoctorRepo.getSize();i++)
		{
		label[i]=new JLabel(DoctorRepo.getDoc(i).toString());
		panel.add(label[i]);
		}
		for(;i<15;i++)
		{
			label[i]=new JLabel();
			panel.add(label[i]);
			
		}
		
		
		JButton addButton=new JButton("Add Doctor");
		addButton.setBounds(130,300,150,80 );
		f.add(addButton);
				
				
		addButton.addActionListener(new ActionListener(){  
		    public void actionPerformed(ActionEvent e){  

		        String id=JOptionPane.showInputDialog(f,"Enter Doctor Id");
		        String name=JOptionPane.showInputDialog(f,"Enter Doctor Name");
		        String department=JOptionPane.showInputDialog(f,"Enter Doctor Department");
		        String age=JOptionPane.showInputDialog(f,"Enter Doctor Age");
		        String number=JOptionPane.showInputDialog(f,"Enter Doctor Phone Number");
		        int i=Integer.parseInt(id);  
		        int a=Integer.parseInt(age);
		        
		        Doctor doc=new Doctor(i, name, department, a, number);
		        int size=DoctorRepo.getSize();
		        label[size].setText(doc.toString());
		        DoctorRepo.addDoctor(doc);
		    
		    }
		    });
		
		
		JButton removeButton=new JButton("Remove Doctor");
		removeButton.setBounds(500,300,150,80 );
		f.add(removeButton);
				
				
		removeButton.addActionListener(new ActionListener(){  
		    public void actionPerformed(ActionEvent e){  

		        String id=JOptionPane.showInputDialog(f,"Enter Doctor Id");
		        int i=Integer.parseInt(id);  
		        DoctorRepo.removeDoctor(i);
		        label[i-1].setText("");
		    
		    }
		    });
		
		
		
		
		
		
		
		
		f.add(panel);
		
		
		f.setSize(900,600);//400 width and 500 height  /using no layout managers  
		f.setVisible(true);
		
	}
	
	
	
}