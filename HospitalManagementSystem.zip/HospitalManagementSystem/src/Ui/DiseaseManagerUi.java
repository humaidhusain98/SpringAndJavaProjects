package Ui;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import entity.Disease;
import repo.DiseaseRepo;;

public class DiseaseManagerUi {
	
	public static void main(String[] args) 
	{
		DiseaseRepo.loadDisease();
		JFrame f=new JFrame();
		f.setTitle("Disease Manager Ui Diptonil Sengupta 113");
		JLabel[] label=new JLabel[15];
		JPanel panel=new JPanel();
		int i;
		for( i=0;i<DiseaseRepo.getSize();i++)
		{
		label[i]=new JLabel(DiseaseRepo.getDisease(i).toString());
		panel.add(label[i]);
		}
		for(;i<15;i++)
		{
			label[i]=new JLabel();
			panel.add(label[i]);
			
		}
		
		
		JButton addButton=new JButton("Add Disease");
		addButton.setBounds(130,300,150,80 );
		f.add(addButton);
				
				
		addButton.addActionListener(new ActionListener(){  
		    public void actionPerformed(ActionEvent e){  

		        String id=JOptionPane.showInputDialog(f,"Enter Disease Id");
		        String name=JOptionPane.showInputDialog(f,"Enter Disease Name");
		        String symptom1=JOptionPane.showInputDialog(f,"Enter First Symptom");
		        String symptom2=JOptionPane.showInputDialog(f,"Enter Second Symptom");
		        String symptom3=JOptionPane.showInputDialog(f,"Enter Third Symptom");
		        int i=Integer.parseInt(id);  
		        
		        Disease dis=new Disease(i, name, symptom1, symptom2, symptom3);
		        int size=DiseaseRepo.getSize();
		        label[size].setText(dis.toString());
		        DiseaseRepo.addDisease(dis);
		    
		    }
		    });
		
		
		JButton removeButton=new JButton("Remove Disease");
		removeButton.setBounds(500,300,150,80 );
		f.add(removeButton);
				
				
		removeButton.addActionListener(new ActionListener(){  
		    public void actionPerformed(ActionEvent e){  

		        String id=JOptionPane.showInputDialog(f,"Enter Disease Id");
		        int i=Integer.parseInt(id);  
		        label[i-1].setText("");
		        DiseaseRepo.removeDisease(i);
		        
		    
		    }
		    });
		
		
		
		
		
		
		
		
		f.add(panel);
		
		
		f.setSize(900,600);//400 width and 500 height  /using no layout managers  
		f.setVisible(true);
		
	}
	
	
	
}