package repo;

import java.util.ArrayList;
import java.util.List;

import entity.Disease;



public class DiseaseRepo
{
	 
		private static List<Disease> disease=new ArrayList<Disease>();
		
		public static void loadDisease() 
		{
		
			Disease d1=new Disease(1,"Malaria","fever","diarrhoea","sweating");
			Disease d2=new Disease(2,"COVID-19","fever","cough","tiredness");
			Disease d3=new Disease(3,"Common Cold","fever","cough","congestion");
			Disease d4=new Disease(4,"Conjunctivitis","itchy","fever","headache");
			disease.add(d1);
			disease.add(d2);
			disease.add(d3);
			disease.add(d4);
	
		
			
			
		}
		
		
		public static void addDisease(Disease d) 
		{
			disease.add(d);	
		}
		
		public static void removeDisease(int id) 
		{
			for(int i=0;i<disease.size();i++)
			{
				Disease d=disease.get(i);
				if(d.getId()==id)
					disease.remove(d);
				
			}
			
		}
		
		public static List<Disease> getAllDiseases()
		{
			
			return disease;
			
		}
		
		public static Disease getDisease(int id) {
			Disease dis=disease.get(id);
			return dis;
		}
		
		public static int getSize() {
			return disease.size();
		} 
	
		public static Disease searchDiseaseName(String name) 
		{
			for(int i=0;i<disease.size();i++)
			{
				if(disease.get(i).getName().equals(name)) 
				{
					return disease.get(i);
					
				}
				
				
			}
			return null;
			
		}
		
		
	
	
	
}
