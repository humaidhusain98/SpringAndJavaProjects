package repo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import entity.Doctor;

public class DoctorRepo 
{
	
	
//	
	
	 
	private static List<Doctor> docs=new ArrayList<Doctor>();
	
	public static void loadDocs() 
	{
		Doctor d1=new Doctor(1,"Hassan Iqbal","Opthalogomist",45,"+918451268521");
		Doctor d2=new Doctor(2,"Ram Tripathi","Physician",50,"+918451268521");
		Doctor d3=new Doctor(3,"Arnab Chowdhary","Cardiologist",35,"+918451268521");
		Doctor d4=new Doctor(4,"Aadarsh Goswami","Dermatologist",40,"+918452522521");
		Doctor d5=new Doctor(5,"Gaurav Ghosh","Physician",42,"+918451211821");
		Doctor d6=new Doctor(6,"Anando Acharya","Cardiologist",43,"+919821268521");
		Doctor d7=new Doctor(7,"Rishav Sinha","Opthalmologist",33,"+919874268521");
		docs.add(d1);
		docs.add(d2);
		docs.add(d3);
		docs.add(d4);
		docs.add(d5);
		docs.add(d6);
		docs.add(d7);
		
		
	}
	
	
	public static void addDoctor(Doctor d) 
	{
		docs.add(d);	
	}
	
	public static void removeDoctor(int id) 
	{
		for(int i=0;i<docs.size();i++)
		{
			Doctor d=docs.get(i);
			if(d.getId()==id)
				docs.remove(d);
			
		}
		
	}
	
	public static List<Doctor> getAllDoctors()
	{
		
		return docs;
		
	}
	
	public static Doctor getDoc(int id) {
		Doctor doctor=docs.get(id);
		return doctor;
	}
	
	public static int getSize() {
		return docs.size();
	} 
	
	
	public static Doctor searchDocName(String name)
	{
		for(int i=0;i<docs.size();i++)
		{
			if(docs.get(i).getName().equals(name)) 
			{
				return docs.get(i);
				
			}
			
			
		}
		return null;
		
	}
	

	
	

}
